package minesweep;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MineSweeper {

	private final static int ASSIGNMENT = 0, BEGINNER = 1, INTERMEDIATE = 2, EXPERT = 3; // index of each of the difficulties available
	private final static int ROW = 0, COL = 1, MINES = 2;  // indexes of the information in the VALUES array
	private final static int [][] VALUES = {{5, 5, 3}, {8, 8, 10}, {16, 16, 40}, {16, 32, 99}}; // rows, cols, and mines for each difficulty
	private static final int[][] ASSIGNMENT_GRID = {{0,0,0,0,0},{0,1,0,0,0},{0,0,0,1,0},{0,0,0,1,0},{0,0,0,0,0}}; // 1's are Mines
	
	private final static int DEFAULT = 2; // change this to change the default starting difficutly
	
	
	private int difficulty;
	public static boolean gameOver;
	private boolean newGame, firstClick;
	private JFrame frame;
	private JPanel all, top, center;
	private JButton face, timer, mines;
	private JMenuBar menu;
	private JMenu fileMenu, newGameSubMenu;
	private JMenuItem newAssignment, newBeginner, newIntermediate, newExpert, exit;
	private MineSweeperButton[][] grid; 
	private int[][] map;
	private int time, totalMines;
	
	public static void main(String[]args) {
		MineSweeper assignment6 = new MineSweeper();
		assignment6.execute();
	}
	
	public void execute() {
		difficulty = DEFAULT;
		initializeFrame();
		initializeMenu();
		while(true) {
			gameOver = false;
			this.newGame = false;
			this.firstClick = true;
			setMap();
			setTopButtons();
			frame.setSize(VALUES[difficulty][COL]*33, VALUES[difficulty][ROW]*33 + 102);
			frame.validate();
			frame.repaint();
			while(!update()){
				// game running
			}
			clearComponents();
		}
	}
	
	public void clearComponents(){
		frame.getContentPane().removeAll();
		frame.invalidate();
	}
	
	public boolean update(){
		
		boolean mineClicked = false;
		int flagCount = 0, minesFlagged = 0, uncoveredCount = 0;
		for(int i = 0; i < VALUES[difficulty][ROW]; i++) {
			for(int j = 0; j < VALUES[difficulty][COL]; j++) {
				if(gameOver) { break; }
				if(firstClick && grid[i][j].getState() <= 8 && grid[i][j].getNum() > 0 && difficulty != ASSIGNMENT){ badClick(i,j);}
				if(grid[i][j].getState() == MineSweeperButton.FLAG){
					flagCount ++;
					if(grid[i][j].IS_A_MINE){
						minesFlagged ++;
					}
				}
				if(grid[i][j].getState() <= 8) {  //means that it has been uncovered 
					uncoveredCount ++;
				}
				if(grid[i][j].getState() == MineSweeperButton.MINE_RED){
					mineClicked = true;
					if(firstClick && difficulty != ASSIGNMENT){
						mineClicked = false;
						badClick(i, j);
					}
				}
			}
		}
		
		if(uncoveredCount > 0){
			firstClick = false;
		}
			
		if(mineClicked){
			gameOver = true;
			face.setIcon(new ImageIcon(MineSweeperButton.ICON_PATHS[MineSweeperButton.FACE_DEAD]));
		}else if(minesFlagged == VALUES[difficulty][MINES]){
			gameOver = true;
			face.setIcon(new ImageIcon(MineSweeperButton.ICON_PATHS[MineSweeperButton.FACE_WIN]));
			JOptionPane.showMessageDialog(null, "Congratulations you won!");
		}else if(uncoveredCount == VALUES[difficulty][ROW] * VALUES[difficulty][COL] - VALUES[difficulty][MINES]) {
			gameOver = true;
			face.setIcon(new ImageIcon(MineSweeperButton.ICON_PATHS[MineSweeperButton.FACE_WIN]));
			JOptionPane.showMessageDialog(null, "Congratulations you won!");
		}
		
		mines.setText(String.valueOf(Math.max((VALUES[difficulty][MINES] - flagCount), 0)));
		
		try {Thread.sleep(20);} catch (InterruptedException e) {}
		
		return gameOver && newGame;
	}
	
	public void badClick(int i, int j) {
		firstClick = false;
		clearComponents();
		while(true){
			System.out.println("Bad click");
			setMap();
			if(map[i][j] == 0 && grid[i][j].getNum() == 0){
				grid[i][j].mousePressed(new MouseEvent( grid[i][j], 0, 0L, 0, 0, 0, 0, false, MouseEvent.BUTTON1));
				break;
			}
			clearComponents();
		}
		setTopButtons();
		frame.setSize(VALUES[difficulty][COL]*33, VALUES[difficulty][ROW]*33 + 102);
		frame.validate();
		frame.repaint();
		
	}
	
	public void initializeFrame(){
		frame = new JFrame();
		frame.setTitle("MineSweeper");
		frame.setResizable(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void setMap(){
		setMap(-1, -1);
	}
	
	public void setMap(int badRow, int badCol) {
		if(difficulty == ASSIGNMENT){
			this.map = ASSIGNMENT_GRID;
			this.totalMines = VALUES[ASSIGNMENT][MINES];
		}else{
			generateMap(badRow, badCol);
		}
		all = new JPanel(new BorderLayout());
		center = new JPanel(new GridLayout(VALUES[difficulty][ROW],VALUES[difficulty][COL]));
		grid = new MineSweeperButton[VALUES[difficulty][ROW]][VALUES[difficulty][COL]];

		for(int i = 0; i < VALUES[difficulty][ROW]; i++) {
			for(int j = 0; j < VALUES[difficulty][COL]; j++) {
				int num = 0;
				boolean north = true, east = true, south = true, west = true;
				if(i == 0){ north = false; }
				if(i == map.length -1){ south = false;}
				if(j == 0){ west = false;}
				if(j == map[0].length -1){ east = false; }
				if(north && map[i-1][j] == 1){ num++; }
				if(east && map[i][j+1] == 1) { num++; }
				if(south && map[i+1][j] == 1) {num++; }
				if(west && map[i][j-1] == 1) { num++; }
				if(north && east && map[i-1][j+1] == 1){ num++; }
				if(north && west && map[i-1][j-1] == 1){ num++; }
				if(south && east && map[i+1][j+1] == 1){ num++; }
				if(south && west && map[i+1][j-1] == 1){ num++; }
				
				if(map[i][j] == 0){
					grid[i][j] = new MineSweeperButton(num, false);
					center.add(grid[i][j]);
				}else{
					grid[i][j] = new MineSweeperButton(num, true);
					center.add(grid[i][j]);
				}
			}
		}
		for(int i = 0; i < VALUES[difficulty][ROW]; i++) {
			for(int j = 0; j < VALUES[difficulty][COL]; j++) {
				boolean north = true, east = true, south = true, west = true;
				if(i == 0){ north = false; }
				if(i == map.length -1){ south = false;}
				if(j == 0){ west = false;}
				if(j == map[0].length -1){ east = false; }
				
				if(north){grid[i][j].addNeighbor(grid[i-1][j]); }
				if(east) {grid[i][j].addNeighbor(grid[i][j+1]); }
				if(south){grid[i][j].addNeighbor(grid[i+1][j]); }
				if(west) {grid[i][j].addNeighbor(grid[i][j-1]); }
				
				if(north && east) { grid[i][j].addNeighbor(grid[i-1][j+1]); }
				if(north && west) { grid[i][j].addNeighbor(grid[i-1][j-1]); }
				if(south && east) { grid[i][j].addNeighbor(grid[i+1][j+1]); }
				if(south && west) { grid[i][j].addNeighbor(grid[i+1][j-1]); }
				
				
				
			}
		}
		all.add(center, BorderLayout.CENTER);
		frame.add(all);

	}
	
	public void setTopButtons(){
		top = new JPanel(new GridLayout(1,3));
		mines = new JButton(String.valueOf(totalMines));
		timer = new JButton("000");
		face = new JButton();
		
		face.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e){
				gameOver = true;
				newGame = true;
				face.setIcon( new ImageIcon(MineSweeperButton.ICON_PATHS[MineSweeperButton.FACE_SMILE]));
			}
		});
		face.setIcon( new ImageIcon(MineSweeperButton.ICON_PATHS[MineSweeperButton.FACE_SMILE]));
		top.add(mines);
		top.add(face);
		top.add(timer);
		all.add(top, BorderLayout.NORTH);
	}

	public void generateMap(int badRow, int badCol) {
		map = new int[VALUES[difficulty][ROW]] [VALUES[difficulty][COL]];
		this.totalMines = VALUES[difficulty][MINES];
		Random ran = new Random();
		for(int i = 0; i < totalMines; i++) {
			int row = ran.nextInt(VALUES[difficulty][ROW]);
			int col = ran.nextInt(VALUES[difficulty][COL]);
			if(map[row][col] == 1 || (row == badRow && col == badCol) ){
				i --;
			}else{
				map[row][col] = 1; 
			}
		}
	}
	
	public void initializeMenu() {
		menu = new JMenuBar();
		fileMenu = new JMenu("File");
		newGameSubMenu = new JMenu("New Game");
		exit = new JMenuItem("Exit");
		newAssignment = new JMenuItem("Assignment");
		newBeginner = new JMenuItem("Beginner");
		newIntermediate = new JMenuItem("Intermediate");
		newExpert = new JMenuItem("Expert");
		newAssignment.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e){
				gameOver = true;
				newGame = true;
				difficulty = ASSIGNMENT;
			}
		});
		newBeginner.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				gameOver = true;
				newGame = true;
				difficulty = BEGINNER;
			}
		});
		newIntermediate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				gameOver = true;
				newGame = true;
				difficulty = INTERMEDIATE;
			}
			
		});
		newExpert.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				newGame = true;
				gameOver = true;
				difficulty = EXPERT;
			}
		});
		exit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e){
				System.exit(0);
			}
		});
		
		newGameSubMenu.add(newAssignment);
		newGameSubMenu.add(newBeginner);
		newGameSubMenu.add(newIntermediate);
		newGameSubMenu.add(newExpert);
		fileMenu.add(newGameSubMenu);
		fileMenu.add(exit);
		menu.add(fileMenu);
		frame.setJMenuBar(menu);
	}
}
