package sort;

public class MergeSort implements Sorter {

	private String name;
	
	public MergeSort () {
		this.name = "MergeSort: ";
	}
	
	@Override
	public int[] sort(int[] unsorted) {
		mergeSort(unsorted, 0, unsorted.length);
		return unsorted;
	}
	
	public void mergeSort(int[] unsorted, int left, int right) {
		
		
		if(left - right < 2) {
			return; 
		}
		
		
		

	}

}
