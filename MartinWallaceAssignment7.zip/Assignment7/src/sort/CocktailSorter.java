package sort;

public class CocktailSorter implements Sorter{

	private String name; 
	
	public CocktailSorter () {
		this.name = "Cocktail sorter: ";
	}
	
	public String toString() {
		return this.name;
	}
	
	@Override
	public int[] sort(int[] unsorted) {
		return cocktailSort(unsorted);
	}

	public static int[] cocktailSort(int[] unsorted) { 
		
		boolean swapped;
		do { 
			swapped = false;
			for(int i = 0; i < unsorted.length-1; i++) {
				if(unsorted[i] > unsorted[i+1]){
					swap(unsorted, i, i+1);
					swapped = true;
				}
			}
			if(!swapped){ break; } 
			
			for(int i = unsorted.length-2; i >= 0; i--) {
				if(unsorted[i] > unsorted[i+1]){
					swap(unsorted, i, i+1);
					swapped = true;
				}
			}
			
			
		}while( swapped);
		
		return unsorted;
	}
	
	private static void swap(int[] ar, int i, int j) {
		int temp = ar[i];
		ar[i] = ar[j];
		ar[j] = temp;
	}
}
