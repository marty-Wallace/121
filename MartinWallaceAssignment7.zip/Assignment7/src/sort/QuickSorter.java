package sort;

public class QuickSorter implements Sorter {

	private String name;
	
	public QuickSorter() {
		this.name = "Quicksort sorter: ";
	}

	public String toString() {
		return this.name;
	}
	
	@Override
	public int[] sort(int[] unsorted) {
		return quicksort(unsorted, 0, unsorted.length-1);
	}
	
	/**
	 * 
	 * @param unsorted
	 * @return
	 */
	private static int[] quicksort(int[] unsorted, int lowerIndex, int higherIndex) {
		
		int i = lowerIndex; 
		int j = higherIndex;
		
		int pivot = unsorted[lowerIndex+(higherIndex-lowerIndex)/2];
		
		while(i <= j) {
			
			while(unsorted[i] < pivot) {
				i ++; 
			}
			
			while(unsorted[j] > pivot) {
				j -- ; 
			}
			
			if(i <= j ) {
				swap(unsorted, i, j);
				i ++;
				j --;
			}
			
		}
		
		if(lowerIndex < j) {
			quicksort(unsorted, lowerIndex, j);
		}
		if( i < higherIndex) {
			quicksort(unsorted, i, higherIndex);
		}
		
		
		return unsorted;
	}
	
	private static void swap(int[] ar, int i, int j) {
		int temp = ar[i];
		ar[i] = ar[j];
		ar[j] = temp;
	}
}
