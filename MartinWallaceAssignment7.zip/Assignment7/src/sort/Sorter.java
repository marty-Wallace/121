package sort;

public interface Sorter {
	
	public abstract int[] sort (int[] unsorted);
	
}
