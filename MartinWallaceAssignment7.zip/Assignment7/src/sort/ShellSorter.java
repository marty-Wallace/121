package sort;



public class ShellSorter implements Sorter {

	private String name; 
	
	public ShellSorter() {
		this.name = "Shell sorter: ";
	}
	
	public String toString() {
		return this.name;
	}
	
	@Override
	public int[] sort(int[] unsorted) {
		return shellSort(unsorted);
	}

	
	private static int[] shellSort(int[] unsorted) {
		int inner, outer;
		int temp;
		
		int gap = 1; 
		//set size of gap relative to unsorted length
		while(gap <= unsorted.length/3) { gap = gap*3 + 1; } 
	
		while(gap > 0) { //  sorting...
			
			for(outer = gap; outer < unsorted.length; outer ++) {
				temp = unsorted[outer];
				inner = outer;
				
				while( inner > gap -1 && unsorted[inner -gap] >= temp) {
					unsorted[inner] = unsorted[inner -gap];
					inner -= gap;
				}
				unsorted[inner] = temp;
			}
			gap = (gap-1)/3;
			
		}
		
		return unsorted; 
	}
}
