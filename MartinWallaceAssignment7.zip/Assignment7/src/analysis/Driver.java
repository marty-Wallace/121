package analysis;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import sort.CocktailSorter;
import sort.QuickSorter;
import sort.ShellSorter;
import sort.Sorter;

public class Driver {
	
	public static void main(String[] args) {
		
		ArrayList<Sorter> sorts = new ArrayList<Sorter>();
		
		sorts.add(new QuickSorter());
		sorts.add(new CocktailSorter());
		sorts.add(new ShellSorter());
		
		Random ran = new Random();
		
		int num = 1000000; 
		
		int tester [] = new int [num];
		
		for(int i = 0; i < num; i++) {
			
			tester[i] = ran.nextInt(4);
			
		}
		
		tester[100] = Integer.MIN_VALUE;
		
		for(Sorter s : sorts) {
			
			int [] copy = Arrays.copyOf(tester, tester.length);
			long start = System.currentTimeMillis();
			s.sort(copy);
			long end = System.currentTimeMillis();
			System.out.println(s + "time taken: " + (end-start) + "(ms)");
			
		}
		

	}

	public static void printArray(int[] tester) {
		
		for(int i =0; i < tester.length; i++) {
			System.out.print(tester[i] + " " );
		}
		System.out.println();
	}
}
